package net.minecraft.src;

public class ItemCookie extends ItemFood {
	public ItemCookie(int i1, int i2, boolean z3, int i4) {
		super(i1, i2, z3);
		this.maxStackSize = i4;
	}
}
