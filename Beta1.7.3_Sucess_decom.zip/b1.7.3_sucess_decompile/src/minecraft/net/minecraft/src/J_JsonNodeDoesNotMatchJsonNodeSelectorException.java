package net.minecraft.src;

public class J_JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
	J_JsonNodeDoesNotMatchJsonNodeSelectorException(String string1) {
		super(string1);
	}
}
