package net.minecraft.src;

public class BiomeGenSwamp extends BiomeGenBase {
}
