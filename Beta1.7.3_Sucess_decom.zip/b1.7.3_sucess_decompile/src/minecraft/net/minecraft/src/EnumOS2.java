package net.minecraft.src;

public enum EnumOS2 {
	linux,
	solaris,
	windows,
	macos,
	unknown;
}
