package net.minecraft.src;

public class KeyBinding {
	public String keyDescription;
	public int keyCode;

	public KeyBinding(String string1, int i2) {
		this.keyDescription = string1;
		this.keyCode = i2;
	}
}
