package net.minecraft.src;

class Empty2 {
}
