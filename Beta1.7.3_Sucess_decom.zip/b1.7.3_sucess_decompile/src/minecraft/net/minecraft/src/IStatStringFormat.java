package net.minecraft.src;

public interface IStatStringFormat {
	String formatString(String string1);
}
